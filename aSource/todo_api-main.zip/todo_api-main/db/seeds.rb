# frozen_string_literal: true

# seeds.rb file is launched during rake db:seed command.
